//
// Created by Jarvis on 2023-02-01.
//
#include "board_sensors.hpp"