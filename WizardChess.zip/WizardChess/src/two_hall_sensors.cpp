// 2 Hall effect sensor

// #include <Arduino.h>
// #include "flash.h"

// #define LEDD 22
// // the setup function runs once when you press reset or power the board
// void setup() {
//   // initialize digital pin LED_BUILTIN as an output.
//   Serial.begin(9600);
//   pinMode(22, OUTPUT);
//   // pinMode(2, INPUT);
// }

// // the loop function runs over and over again forever
// void loop() {
//   // flash_led();
  
//   delay(100);                      // wait for a second
//   Serial.println("Sensors:");
//   Serial.println(touchRead(4));
//   Serial.println(touchRead(15));
//   if(touchRead(4) < 30 || touchRead(15) < 30){
//     digitalWrite(22, HIGH);  // turn the LED on (HIGH is the voltage level)
  
//   }else{
//     digitalWrite(22, LOW);   // turn the LED off by making the voltage LOW
    
//   }
  
// }


// 2 Hall effect sensor

// #include <Arduino.h>
// #include "flash.h"

// #define LEDD 22
// // the setup function runs once when you press reset or power the board
// void setup() {
//   // initialize digital pin LED_BUILTIN as an output.
//   Serial.begin(9600);
//   pinMode(22, OUTPUT);
//   // pinMode(2, INPUT);
// }

// // the loop function runs over and over again forever
// void loop() {
//   // flash_led();
  
//   delay(100);                      // wait for a second
//   Serial.println("Sensors:");
//   Serial.println(touchRead(4));
//   Serial.println(touchRead(15));
//   if(touchRead(4) < 30 || touchRead(15) < 30){
//     digitalWrite(22, HIGH);  // turn the LED on (HIGH is the voltage level)
  
//   }else{
//     digitalWrite(22, LOW);   // turn the LED off by making the voltage LOW
    
//   }
  
// }

