#include <Arduino.h>
#include "definitions.hpp"


void control_electromagnet(){


    while(true){
        

    }
}