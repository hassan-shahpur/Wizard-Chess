var searchData=
[
  ['print_5fboard_5fstate_0',['print_board_state',['../classboard.html#acda221dd82e3697783dde37b251a2635',1,'board::print_board_state()'],['../classboard__sensors.html#adc72ba8b252007eeaefe67405fff2113',1,'board_sensors::print_board_state()']]],
  ['print_5fvalid_5fmoves_1',['print_valid_moves',['../classboard.html#a226c4bb9e3d4fa23928337ea9393a891',1,'board']]]
];
