var searchData=
[
  ['game_0',['game',['../classgame.html',1,'game'],['../classgame.html#ad6f024b73cac5928fd3cd3e464d5afd3',1,'game::game()']]],
  ['get_5fboard_5fstate_1',['get_board_state',['../classboard__sensors.html#a86925c017a05fcbb248131d597262d87',1,'board_sensors']]],
  ['get_5fnumber_5fof_5fmoves_2',['get_number_of_moves',['../classgame.html#ae55eda9e3999756e82dabe6168514bfa',1,'game']]],
  ['get_5fsquare_5fstate_3',['get_square_state',['../classboard__sensors.html#adc44a6873f1e110fa3e8578c54e24870',1,'board_sensors']]],
  ['get_5fuser_5fmove_4',['get_user_move',['../classboard.html#ab8ac3e7dfa80a57d43a717f292388fb4',1,'board']]],
  ['getdepth_5',['getDepth',['../classstockfish__bot.html#a8492172fad10b1db2a8ac740065246e8',1,'stockfish_bot']]],
  ['getmovesequence_6',['getMoveSequence',['../classstockfish__bot.html#a38a6bd96f052a901a2e5e0ad2d15065b',1,'stockfish_bot']]]
];
