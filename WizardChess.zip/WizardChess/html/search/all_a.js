var searchData=
[
  ['verify_5fstarting_5fposition_0',['verify_starting_position',['../classboard.html#a3bec565e150875c26d71f4748228432b',1,'board']]]
];
