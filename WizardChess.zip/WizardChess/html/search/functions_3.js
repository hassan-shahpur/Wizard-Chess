var searchData=
[
  ['identify_5fuser_5fmove_0',['identify_user_move',['../classboard.html#af620da7798b2e472197a7166539f92c4',1,'board']]],
  ['is_5fcheckmate_1',['is_checkmate',['../classboard.html#a8691914f0814ca8706d4559bc1ca60ac',1,'board']]],
  ['is_5fvalid_5fmove_2',['is_valid_move',['../classboard.html#abb306aaf820e646d7ec8990a9cc135d7',1,'board']]]
];
