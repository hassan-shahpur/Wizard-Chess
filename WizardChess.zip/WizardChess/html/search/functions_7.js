var searchData=
[
  ['tick_5fx_0',['tick_x',['../classsteppers.html#a4dba337ea6177b8eed402c36d76e3b73',1,'steppers']]],
  ['tick_5fy_1',['tick_y',['../classsteppers.html#abbe07340be76305217d2745806136f47',1,'steppers']]]
];
