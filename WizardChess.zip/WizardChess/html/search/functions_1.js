var searchData=
[
  ['board_0',['board',['../classboard.html#a3b7ae07934f330439b4dc4f79aa97144',1,'board']]],
  ['board_5fsensors_1',['board_sensors',['../classboard__sensors.html#af4d7bbe5bbe4def8a8fb4fbbdb45542b',1,'board_sensors']]]
];
