var searchData=
[
  ['_7estockfish_5fbot_0',['~stockfish_bot',['../classstockfish__bot.html#a72e23c52fd9b80451d9dd0350f302094',1,'stockfish_bot']]]
];
