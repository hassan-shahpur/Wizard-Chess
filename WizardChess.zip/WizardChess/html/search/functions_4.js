var searchData=
[
  ['make_5fmove_0',['make_move',['../classboard.html#a49770c108ab59bb7e3582e1827de0384',1,'board::make_move()'],['../classsteppers.html#a3e46b6ac743d74d56fef9161016d2520',1,'steppers::make_move()']]]
];
