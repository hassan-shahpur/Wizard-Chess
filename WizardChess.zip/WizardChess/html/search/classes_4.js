var searchData=
[
  ['steppers_0',['steppers',['../classsteppers.html',1,'']]],
  ['stockfish_5fbot_1',['stockfish_bot',['../classstockfish__bot.html',1,'']]]
];
