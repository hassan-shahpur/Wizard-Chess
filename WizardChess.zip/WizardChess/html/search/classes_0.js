var searchData=
[
  ['board_0',['board',['../classboard.html',1,'']]],
  ['board_5fsensors_1',['board_sensors',['../classboard__sensors.html',1,'']]]
];
